# Hospital Bot

Use IBM Watson Assistant to develop a chat bot
## DEMO
Live on Click to Run 

[Run](httpsweb-chat.global.assistant.watson.appdomain.cloudpreview.htmlbackgroundImageURL=https%3A%2F%2Fau-syd.assistant.watson.cloud.ibm.com%2Fpublic%2Fimages%2Fupx-153da05a-c9ba-4cf3-bc8f-d0040d18b487%3A%3A00ba18e9-53ba-4310-9ec2-517c3ecd108e&integrationID=fa69fb98-4bd3-4ab6-b4a8-172f3e1ecddf&region=au-syd&serviceInstanceID=153da05a-c9ba-4cf3-bc8f-d0040d18b487)

  

  
